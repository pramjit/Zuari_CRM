<?php

$_['heading_title']                = 'Search Village';
$_['button_save']                  ='Save';
$_['button_back']                  ='Back';
$_['text_list']                    ='village';
$_['entry_name']                   ='village name';
$_['entry_model']                  ='entry model';
$_['entry_price']                  ='entry price';
$_['entry_status']                 =' Search Village Name';
$_['column_sid']                   ='SID';
$_['column_village_name']          ='Village Name';
$_['column_act']                   ='ACT';
$_['column_district_name']         ='District Name';
$_['column_dealer_name']           ='Dealer Name';
$_['column_date']                  ='Date';
$_['column_pincode']               ='PINCODE';
$_['column_action']                ='Action';
$_['column_state_name']            ='State';