<?php

$_['heading_title']                = 'Create Village';
$_['button_save']='Save';
$_['button_back']='Back';
$_['text_success']='Data add successfully';