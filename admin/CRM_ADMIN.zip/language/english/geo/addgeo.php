<?php

$_['heading_title']                = 'Fill Details of Geo Setting';
$_['button_save']='Save';
$_['button_back']='Back';
$_['text_nation']='Nation';
$_['text_state']='District';
$_['text_district']='District';
$_['text_zone']='State';
$_['text_region']='Territory';
$_['text_area']='Head Quater';
$_['text_territory']='Territory';
$_['text_success']='Data add successfully';

$_['text_check_nation']='Nation Exits!';
$_['text_check_state']='State Exits!';
$_['text_check_territory']='Territory Exits!';
$_['text_check_district']='District Exits!';
$_['text_check_hq']='Head Quarter Exits!';
