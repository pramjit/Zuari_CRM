<?php

$_['heading_title']                = 'Milk Collection Daily Report';
$_['button_save']                  ='Save';
$_['button_back']                  ='Back';
$_['text_list']                    ='Search';
$_['entry_name']                   ='Product name';
$_['entry_model']                  ='entry model';
$_['entry_price']                  ='entry price';
$_['entry_status']                 =' Search Geo Name';


$_['column_mdo_name']              ='Mdo Name';
$_['column_market']              ='Market';
$_['column_date']                ='Date';
$_['column_milkcenter_person']              ='Milk Center Person';

$_['column_contact']                 ='Contact Number';

$_['daily_collection']                   ='Daily Collection';
$_['daily_cow_collection']           ='Daily Cow Collection';
$_['daily_buffalo_collection']           ='Daily Buffalo Collection';
$_['farmer_connected']           ='Farmer Connected';
$_['current_feed']           ='Current Feed';

