<?php

$_['heading_title']                = 'Farmer Detail Report';
$_['button_save']                  ='Save';
$_['button_back']                  ='Back';
$_['text_list']                    ='Search';
$_['entry_name']                   ='Product name';
$_['entry_model']                  ='entry model';
$_['entry_price']                  ='entry price';
$_['entry_status']                 =' Search Geo Name';


$_['farmer_name']              ='Farmer name';
$_['farmer_mobile']              ='Farmer mobile number';
$_['dateof_creation']                ='Date of creation';
$_['nof_milking_cow']              ='Number of milking cow';
$_['nof_total_cow']              ='Total number of cow';
$_['current_supplier']                 ='Current supplier';

$_['daily_milkIn_ltr']                   ='Daily milk(in litter) ';
$_['mdo_name']           ='Mdo name';
$_['market']           ='Market';
$_['milk_collection']           ='Created From';
$_['group_meeting']           ='Group meeting';
$_['direct_visit']           ='Direct visit';

