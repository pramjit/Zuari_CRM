<?php

$_['heading_title']                = 'Market Activity Report';
$_['button_save']                  ='Save';
$_['button_back']                  ='Back';
$_['text_list']                    ='Search';
$_['entry_name']                   ='Product name';
$_['entry_model']                  ='entry model';
$_['entry_price']                  ='entry price';
$_['entry_status']                 =' Search Geo Name';


$_['column_mdo_name']              ='Mdo Name';
$_['market_name']              ='Market Name';
$_['pos_added']                ='Pos Added';
$_['milk_colc_added']              ='Milk collection added';

$_['farmer_added']                 ='Farmer Added';

$_['fgm_added']                   ='FGM Added';

