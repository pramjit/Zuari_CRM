<?php

$_['heading_title']                = 'Monthly Report';
$_['button_save']                  ='Save';
$_['button_back']                  ='Back';
$_['text_list']                    ='Search';
$_['entry_name']                   ='Product name';
$_['entry_model']                  ='entry model';
$_['entry_price']                  ='entry price';
$_['entry_status']                 =' Search Monthly Name';



$_['column_market']              ='Market';
$_['column_mdo_name']              ='Mdo';
$_['column_Activity']                 ='Activity';

$_['day1']              ='day1';
$_['day2']              ='day2';
$_['day3']              ='day3';
$_['day4']              ='day4';
$_['day5']              ='day5';
$_['day6']              ='day6';
$_['day7']              ='day7';
$_['day8']              ='day8';
$_['day9']              ='day9';
$_['day10']              ='day10';
$_['day11']              ='day11';
$_['day12']              ='day12';
$_['day13']              ='day13';
$_['day14']              ='day14';
$_['day15']              ='day15';
$_['day16']              ='day16';
$_['day17']              ='day17';
$_['day18']              ='day18';
$_['day19']              ='day19';
$_['day20']              ='day20';
$_['day21']              ='day21';
$_['day22']              ='day23';
$_['day23']              ='day24';
$_['day24']              ='day26';
$_['day25']              ='day25';
$_['day26']              ='day26';
$_['day27']              ='day27';
$_['day28']              ='day28';
$_['day29']              ='day29';
$_['day30']              ='day30';
$_['day31']              ='day31';


$_['column_season_name']           ='Season Name';


