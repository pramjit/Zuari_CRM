<?php

$_['heading_title']                = 'FGM Daily Report';
$_['button_save']                  ='Save';
$_['button_back']                  ='Back';
$_['text_list']                    ='Search';
$_['entry_name']                   ='Product name';
$_['entry_model']                  ='entry model';
$_['entry_price']                  ='entry price';
$_['entry_status']                 =' Search Geo Name';


$_['column_mdo_name']              ='Mdo Name';
$_['column_market']              ='Market';
$_['column_date']                ='FGM Date';
$_['column_vill_name']              ='Village name';

$_['number_of_farmer']                 ='Number of farmer';


