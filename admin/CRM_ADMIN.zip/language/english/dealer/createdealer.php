<?php

$_['heading_title']                = 'Retailer Creation';
$_['button_save']='Save';
$_['button_back']='Back';
$_['text_success']='Data add successfully';



