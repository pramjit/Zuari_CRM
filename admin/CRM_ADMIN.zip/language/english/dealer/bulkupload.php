<?php

$_['heading_title']                = 'Farmer bulk upload';
$_['file_restore']='File upload';
$_['button_download']='Download sample file';
$_['button_upload']="Upload excel";
$_['text_success']='Data add successfully';