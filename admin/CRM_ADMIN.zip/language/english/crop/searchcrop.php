<?php

$_['heading_title']                = 'Search Crop';
$_['button_save']                  ='Save';
$_['button_back']                  ='Back';
$_['text_list']                    ='Search';
$_['entry_name']                   ='Product name';
$_['entry_model']                  ='entry model';
$_['entry_price']                  ='entry price';
$_['entry_status']                 =' Search Product Name';
$_['column_sid']                   ='SID';
$_['column_crop_name']             ='Crop Name';
$_['column_season_name']           ='Season Name';
$_['column_act']                   ='ACT';
$_['text_success']='Data add successfully';
