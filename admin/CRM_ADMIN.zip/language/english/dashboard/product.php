<?php
// Heading
$_['heading_title'] = 'Total Product';

// Text
$_['text_view'] = 'View more...';