<?php
// Heading
$_['heading_title'] = 'Total User';

// Text
$_['text_view'] = 'View more...';