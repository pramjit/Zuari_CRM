<?php
// Heading
$_['heading_title'] = 'Total Farmer';

// Text
$_['text_view'] = 'View more...';