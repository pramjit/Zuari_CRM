<?php
// Heading
$_['heading_title'] = 'Total Dealer';

// Text
$_['text_view'] = 'View more...';