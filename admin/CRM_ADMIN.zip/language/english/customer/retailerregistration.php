<?php

$_['heading_title']                = 'Retailer Registration';
$_['button_save']='Save';
$_['button_back']='Back';
$_['text_nation']='Nation';
$_['text_state']='State';
$_['text_district']='District';
$_['text_success']='Data add successfully';