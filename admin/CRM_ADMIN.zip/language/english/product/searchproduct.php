<?php

$_['heading_title']                = 'Search Product';
$_['button_save']                  ='Save';
$_['button_back']                  ='Back';
$_['text_list']                    ='Search';
$_['entry_name']                   ='Product name';
$_['entry_model']                  ='entry model';
$_['entry_price']                  ='entry price';
$_['entry_status']                 =' Search Product Name';
$_['column_sid']                   ='SID';
$_['column_village_name']          ='Product Name';
$_['column_act']                   ='ACT';
$_['column_district_name']         ='Product Category';
$_['column_dealer_name']           ='Dealer Name';
$_['column_date']                  ='Date';
$_['column_pincode']               ='PINCODE';
$_['column_action']                ='Action';
$_['column_product_group']         ='Group';