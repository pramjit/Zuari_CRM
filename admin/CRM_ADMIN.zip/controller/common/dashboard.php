<?php
class ControllerCommonDashboard extends Controller {
	public function index() {
		$this->load->language('common/dashboard');

		$this->document->setTitle($this->language->get('heading_title'));

		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_sale'] = $this->language->get('text_sale');
		$data['text_map'] = $this->language->get('text_map');
		$data['text_activity'] = $this->language->get('text_activity');
		//$data['text_recent'] = $this->language->get('text_recent');

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);
		
		// Check install directory exists
		
			$data['error_install'] = '';
		

		$data['token'] = $this->session->data['token'];
                $data['customer'] = $this->load->controller('dashboard/customer');
                $data['farmer'] = $this->load->controller('dashboard/totalfarmer');
                $data['dealer'] = $this->load->controller('dashboard/totaldealer');
                $data['jeepcampaign'] = $this->load->controller('dashboard/totaljeepcampaign');
                $data['product'] = $this->load->controller('dashboard/totalproduct');
               
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');		
		$data['footer'] = $this->load->controller('common/footer');
	       
			
		$this->response->setOutput($this->load->view('common/dashboard.tpl', $data));
	}
}
